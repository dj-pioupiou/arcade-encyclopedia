const builtins = [
{id:"sf2",title:"Street Fighter II: The World Warrior",year:"1991",maker:"Capcom",system:"CPS-1",genre:"Combat",developer:"Capcom",publisher:"Capcom",players:"1-2",desc:"Jeu de combat emblématique de Capcom, publié sur CP System. Cette fiche sert de référence visuelle pour Arcade Encyclopedia.",cabinet:"https://commons.wikimedia.org/wiki/Special:FilePath/Street%20Fighter%20II%20arcade%20machine.jpg?width=1000",flyer:"https://flyers.arcade-museum.com/videogame-flyers/1/street-fighter-ii-the-world-warrior-01900-01.jpg",source1:"https://commons.wikimedia.org/wiki/File:Street_Fighter_II_arcade_machine.jpg",source2:"https://flyers.arcade-museum.com/videogames/show/1900"},
{id:"pacman",title:"Pac-Man",year:"1980",maker:"Namco",system:"Pac-Man hardware",genre:"Labyrinthe",developer:"Namco",publisher:"Namco / Midway",players:"1-2 alternés",desc:"Le classique de Namco de 1980, présenté avec une image de borne et un flyer commercial.",cabinet:"https://commons.wikimedia.org/wiki/Special:FilePath/Arcade1up%20Golden%20Tee%2C%20Arcade1up%20Pac%20Man%20Arcade%20Games.jpg?width=1000",flyer:"https://flyers.arcade-museum.com/videogame-flyers/0/pac-man-00724-01.jpg",source1:"https://commons.wikimedia.org/wiki/Category:Pac-Man_arcade_machines",source2:"https://flyers.arcade-museum.com/videogames/show/723"},
{id:"metalslug",title:"Metal Slug",year:"1996",maker:"SNK",system:"Neo Geo MVS",genre:"Run and gun",developer:"Nazca",publisher:"SNK",players:"1-2",desc:"Run and gun de 1996 célèbre pour son animation et son action coopérative sur Neo Geo MVS.",cabinet:"https://commons.wikimedia.org/wiki/Special:FilePath/Mus%C3%A9e%20M%C3%A9canique%20222.JPG?width=1000",flyer:"https://flyers.arcade-museum.com/videogame-flyers/3/metal-slug-03511-01.jpg",source1:"https://commons.wikimedia.org/wiki/File:Mus%C3%A9e_M%C3%A9canique_222.JPG",source2:"https://flyers.arcade-museum.com/videogames/show/3515"}
];
let custom = JSON.parse(localStorage.getItem("ae_custom_games") || "[]");
let games = [...builtins, ...custom];
let current = games[0];
let flags = JSON.parse(localStorage.getItem("ae_flags") || "{}");
let mode = "all";
const $ = id => document.getElementById(id);
function esc(s){return String(s??"").replace(/[&<>"']/g,m=>({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#039;"}[m]))}
function safeUrl(u){ try { const x=new URL(u); return /^https?:$/.test(x.protocol)?x.href:""; } catch { return ""; } }
function show(g){
  if(!g) return; current=g;
  $("title").textContent=g.title.toUpperCase(); $("crumbTitle").textContent=g.title; $("crumbSystem").textContent=g.system;
  $("maker").textContent=g.maker; $("year").textContent=g.year; $("genre").textContent=g.genre; $("system").textContent=g.system;
  $("developer").textContent=g.developer||g.maker; $("publisher").textContent=g.publisher||g.maker; $("players").textContent=g.players||"—"; $("desc").textContent=g.desc||"";
  $("cabinet").src=safeUrl(g.cabinet)||safeUrl(g.flyer); $("flyer").src=safeUrl(g.flyer)||safeUrl(g.cabinet);
  $("source1").href=safeUrl(g.source1)||"#"; $("source2").href=safeUrl(g.source2)||safeUrl(g.source1)||"#";
  $("gallery").innerHTML=[g.cabinet,g.flyer].filter(Boolean).map(x=>`<div class="thumb"><img src="${safeUrl(x)}" alt=""></div>`).join("");
  updateFlags();
  window.scrollTo({top:0,behavior:"smooth"});
}
function filtered(){
  const q=$("search").value.toLowerCase().trim();
  return games.filter(g=>{
    const matches=[g.title,g.maker,g.system,g.genre,g.year].join(" ").toLowerCase().includes(q);
    if(!matches) return false;
    if(mode==="own") return !!flags[g.id]?.own;
    if(mode==="wish") return !!flags[g.id]?.wish;
    if(mode==="fav") return !!flags[g.id]?.fav;
    return true;
  });
}
function render(){
  const list=filtered();
  $("library").innerHTML=list.length ? list.map(g=>`<div class="tile" data-id="${esc(g.id)}"><img src="${safeUrl(g.flyer||g.cabinet)}" alt="${esc(g.title)}"><div><b>${esc(g.title)}</b><small>${esc(g.maker)} · ${esc(g.year)} · ${esc(g.system)}</small>${g.id.startsWith("custom-")?'<span class="badge">AJOUT LOCAL</span>':""}</div></div>`).join("") : '<div class="empty">Aucun jeu pour ce filtre.</div>';
  document.querySelectorAll(".tile").forEach(el=>el.addEventListener("click",()=>show(games.find(x=>x.id===el.dataset.id))));
  $("count").textContent=`${list.length} jeu${list.length>1?"x":""}`;
}
function toggleFlag(k){flags[current.id]??={};flags[current.id][k]=!flags[current.id][k];localStorage.setItem("ae_flags",JSON.stringify(flags));updateFlags();render()}
function updateFlags(){for(const k of ["own","fav","wish"])$(k).classList.toggle("on",!!flags[current.id]?.[k])}
function toggleAdd(){$("addform").classList.toggle("open")}
function addGame(e){
  e.preventDefault();
  const g={id:"custom-"+Date.now(),title:$("aTitle").value,year:$("aYear").value,maker:$("aMaker").value||"Inconnu",system:$("aSystem").value||"Inconnu",genre:$("aGenre").value||"Autre",developer:$("aMaker").value,publisher:$("aMaker").value,players:"—",cabinet:$("aImage").value,flyer:$("aFlyer").value||$("aImage").value,source1:$("aSource").value,source2:$("aSource").value,desc:$("aDesc").value};
  custom.push(g); localStorage.setItem("ae_custom_games",JSON.stringify(custom)); games=[...builtins,...custom];
  e.target.reset(); $("addform").classList.remove("open"); mode="all"; setActive("all"); render(); show(g);
}
function setActive(next){
 mode=next;
 document.querySelectorAll(".nav button").forEach(b=>b.classList.toggle("active",b.dataset.mode===next));
 render();
}
document.addEventListener("DOMContentLoaded",()=>{
 $("search").addEventListener("input",render);
 $("addButton").addEventListener("click",toggleAdd);
 $("addform").addEventListener("submit",addGame);
 $("own").addEventListener("click",()=>toggleFlag("own"));
 $("fav").addEventListener("click",()=>toggleFlag("fav"));
 $("wish").addEventListener("click",()=>toggleFlag("wish"));
 document.querySelectorAll("[data-mode]").forEach(b=>b.addEventListener("click",()=>setActive(b.dataset.mode)));
 const radio=$("radio");
 const radioStatus=$("radioStatus");
 if(radio && radioStatus){
   radio.addEventListener("playing",()=>radioStatus.textContent="● Arcade Radio est en lecture.");
   radio.addEventListener("waiting",()=>radioStatus.textContent="Connexion à Kohina…");
   radio.addEventListener("error",()=>radioStatus.textContent="Le flux intégré est indisponible ou bloqué. Clique sur OUVRIR LE LECTEUR KOHINA.");
 }
 render(); show(current);
});
