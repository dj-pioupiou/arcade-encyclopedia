@echo off
chcp 65001 >nul
title Arcade Encyclopedia - Phase 2 Alpha PC
cd /d "%~dp0.."
echo.
echo ============================================
echo   ARCADE ENCYCLOPEDIA - PHASE 2 ALPHA PC
echo ============================================
echo.
echo Ouverture dans votre navigateur Windows...
start "" "%CD%\index.html"
exit
