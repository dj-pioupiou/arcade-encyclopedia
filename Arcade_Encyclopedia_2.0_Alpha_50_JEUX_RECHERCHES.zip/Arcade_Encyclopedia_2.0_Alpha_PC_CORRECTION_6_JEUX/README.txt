ARCADE ENCYCLOPEDIA 2.0 ALPHA PC — 63 JEUX — VERSION AUDIT

Corrections :
- aucun onglet Médias vide : LaunchBox + MobyGames + YouTube pour chaque jeu
- aucun onglet Prix vide : prix spécifique vérifié quand disponible, sinon contexte de marché estimatif clairement étiqueté
- statut de vérification visible dans chaque fiche
- nouvelles Box Front JAP AES vérifiées ajoutées quand l'URL directe a été contrôlée
- les Box Front non encore extraites ne sont jamais remplacées par du fan-art
- informations, joueurs et supports conservés
- tracklists VGMRips conservées quand vérifiées

IMPORTANT :
Le statut "A VERIFIER" signifie qu'aucune image ou donnée non vérifiée n'a été inventée.
