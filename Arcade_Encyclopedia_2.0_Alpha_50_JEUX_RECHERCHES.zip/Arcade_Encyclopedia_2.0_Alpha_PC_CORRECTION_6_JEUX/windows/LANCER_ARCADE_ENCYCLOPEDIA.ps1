$root = Split-Path -Parent $PSScriptRoot
Start-Process (Join-Path $root "index.html")
